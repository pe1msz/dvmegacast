<html>
<body>

<?php 
  $RTG_ref = $_POST["RTG_ref"];
  $RTG_mod = $_POST["RTG_mod"];
  $RTG_lab = $_POST["RTG_lab"]; 
  $mode = $_POST["mode"];
  $cont = "";

  if(strlen($RTG_lab) == 0)
  {
    if($mode == "DST") $RTG_lab = $RTG_ref . " " . $RTG_mod;
    if($mode == "DMR") $RTG_lab = $RTG_ref;
    if($mode == "YSF") $RTG_lab = $RTG_ref;

  }

  if($mode == "DST" && strlen($RTG_ref) > 0)
  {
    $RTG_ref = $RTG_ref." ".$RTG_mod; 
    $cont = "DST,".$RTG_ref.",".$RTG_lab.",\n";
  }

  if($mode == "DMR" && strlen($RTG_ref) > 0)
  {
    $cont = "DMR,".$RTG_ref.",".$RTG_lab.",\n";
  }

 if($mode == "YSF" && strlen($RTG_ref) > 0)
  {
    $cont = "YSF,".$RTG_ref.",".$RTG_lab.",\n";
  }



  $fileLocation = getenv("DOCUMENT_ROOT") . "/castmemlist.txt";
  $names=file($fileLocation);

  if(strlen($cont) > 3 && count($names) < 25)
  {
    $new = "";
    foreach($names as $name)
    {
      $name = substr($name,0,-1);

      if(strlen($name) > 3 )
      {  
        $new .= $name;
        $new .= "\n";
      }
    }
      $new .= $cont;

      shell_exec('sudo mount -o remount,rw /');
      $myfile = fopen($fileLocation, "w");
      fwrite($myfile, $new);
      fclose($myfile);
    
  }

?>

<?php header("Location: ./memlist.php"); ?>
</body>
</html>

