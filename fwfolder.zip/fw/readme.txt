Hi Amateur!

All files in this folder have been modified to be used for DVMEGA-Cast use.

The scripts have been modified, and work only for the nano-pi in the Cast unit.

No rights can be claimed, and all rights belong to the original authors as in the files itself,
and are modfied by PE1MSZ (ruud@combitronics.nl).

Enjoy!

